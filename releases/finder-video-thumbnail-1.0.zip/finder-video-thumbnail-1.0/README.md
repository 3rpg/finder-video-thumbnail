# Finder 视频缩略图快速操作

当前版本：`1.0`

在 Finder 中右键视频文件，通过 macOS 的“快速操作”生成一张 1080p 视频缩略图。

## 功能

- 抽取 20 帧。
- 第一帧从第 5 秒开始；如果视频不足 5 秒，则从第 0 秒开始。
- 其余 19 帧在剩余时长内平均分布。
- 拼成 5 x 4 的联系表图片。
- 输出尺寸为 1920 x 1080。
- 生成文件保存在视频同目录，命名为 `原文件名_thumbnail_1080p.jpg`。

## 文件说明

- `create-video-contact-sheet.sh`：实际处理视频的脚本。
- `生成视频缩略图.workflow`：Finder/Automator 快速操作。
- `install-finder-quick-action.sh`：安装脚本，会复制 workflow、启用快速操作，并刷新 Finder。
- `VERSION`：当前版本号。
- `CHANGELOG.md`：版本记录。

## 依赖

需要安装 `ffmpeg`：

```bash
brew install ffmpeg
```

## 安装 Finder 快速操作

在本目录运行：

```bash
chmod +x install-finder-quick-action.sh
./install-finder-quick-action.sh
```

安装脚本会把快速操作安装到：

```text
~/Library/Services/生成视频缩略图.workflow
```

同时会把处理脚本复制到：

```text
~/Library/Application Scripts/com.codex.video-thumbnail/create-video-contact-sheet.sh
```

## 使用方式

安装后在 Finder 中选择一个或多个视频文件，右键选择：

```text
快速操作 > 生成视频缩略图
```

在部分 macOS 版本中，它也可能显示在：

```text
Services / 服务
```

## 如果右键菜单没有出现

先重新运行安装脚本：

```bash
./install-finder-quick-action.sh
```

如果仍然没有出现，打开系统设置手动启用：

```text
系统设置 > 键盘 > 键盘快捷键 > 服务 > 文件和文件夹 > 生成视频缩略图
```

确认已勾选后，重启 Finder：

```bash
killall Finder
```

## 直接命令行使用

```bash
./create-video-contact-sheet.sh /path/to/video.mp4
```

也可以一次传入多个视频：

```bash
./create-video-contact-sheet.sh /path/to/a.mp4 /path/to/b.mov
```

## 版本

当前稳定版本为 `1.0`。
